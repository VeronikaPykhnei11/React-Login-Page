import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import {makeStyles} from '@material-ui/core/styles';
import Logo from "../../assets/images/login-logo.png";
import FooterImage from "../../assets/images/footer-image-login.png";
import {Hidden} from "@material-ui/core";


const useStyles = makeStyles((theme) => ({
    root: {
        height: '100vh',
        backgroundColor: '#EEF2F5'
    },
    image: {
        height: '100vh',
        backgroundImage: `url(${Logo})`,
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        zIndex: 4
    },
    paper: {
        marginRight: theme.spacing(3),
        padding: theme.spacing(2),
        minHeight: '626px',
        minWidth: '566px',
        zIndex:9
    },
    layout: {
        width: 'auto',
        zIndex: 3,
    },
    footer: {
        position: "absolute",
        zIndex: 2,
        bottom: 0,
        marginTop: "auto"
    }
}));

export default function SignInSide() {
    const classes = useStyles();

    return (
        <Grid container className={classes.root}>
            <CssBaseline/>
            <Grid direction="row" container spacing={0}>
                <Hidden xsDown>
                    <Grid item xs={false} sm={6} md={6} className={classes.image}/>
                </Hidden>
                <main className={classes.layout} container
                      direction="column"
                      justify="center"
                      alignItems="flex-end">
                    <Paper className={classes.paper}>

                    </Paper>
                </main>
            </Grid>
            <Grid className={classes.footer} container
                  direction="column"
                  justify="flex-end"
                  alignItems="stretch"
            >
                <img src={FooterImage}/>
            </Grid>
        </Grid>
    );
}