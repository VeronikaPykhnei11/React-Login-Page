import React, {useState} from 'react';
import "./LoginPage.css";
import {Formik, Field, Form} from 'formik'
import Button from '@material-ui/core/Button';
import FooterImage from "../../assets/images/footer-image-login.png";
import FormErrorText from "../../component/FormErrorText/FormErrorText";
import Logo from "../../assets/images/login-logo.png";
import FormFooter from "../../component/FormFooter/FormFooter";
import {LogInSchema} from "../../Schemas/LogInSchema/LogInSchema";
import passwordEye from "../../assets/images/password-eye.svg";
import passwordEyeError from "../../assets/images/password-eye-error.svg";
import Grid from '@material-ui/core/Grid';
import CssBaseline from '@material-ui/core/CssBaseline';
import Paper from '@material-ui/core/Paper';
import styles from './LoginPage.module.css';
import {Hidden, Typography} from "@material-ui/core";




function LoginPage() {
    const [state, handleClick] = useState(false);
    return (
        <Grid container component="main" className={styles.wrapper} alignItems={'center'}>
            <CssBaseline/>
            <Hidden smDown={'true'}>
                <Grid lg={7} className={styles.logoWrapper}>
                    <img src={Logo} alt="logo"/>
                </Grid>
            </Hidden>
            <Grid lg={5} sm={8} md={5} elevation={6} xs={12} square direction="column" className={styles.formWrapper}
                  container
                  justify="flex-end"
                  alignItems="flex-end">
                <Paper className={styles.paperWrapper} alignItems="center" justify="center">
                    <Grid direction="column">
                        <Typography component="h2" variant="h4" className={styles.formTitle} align='center'>
                            LOGIN
                        </Typography>
                        <Formik
                            action="#"
                            aria-label="sign in"
                            className="form-login"
                            initialValues={{
                                email: '',
                                password: ''
                            }}
                            validationSchema={LogInSchema}
                            onSubmit={(values) => {
                                alert("Email: " + values.email + "   " + "Password: " + values.password);
                            }}>
                            {({
                                  values,
                                  handleChange,
                                  handleSubmit,
                                  errors,
                                  touched,
                                  handleBlur,
                                  isValid
                              }) => (
                                <Form autoComplete="off" onSubmit={handleSubmit}>
                                    {console.log(errors.email)}
                                    <div
                                        className={(errors.email && touched.email) ? "error-login-email" : "input-wrapper"}>
                                        <Field
                                            name="email"
                                            className={(errors.email && touched.email) ? "input-data-error" : "input-data"}
                                            type="text"
                                            placeholder="Email address"
                                            label="Email"
                                            validationSchema={LogInSchema}
                                            value={values.email}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                        />
                                    </div>
                                    {errors.email && touched.email && (
                                        <FormErrorText class="error-text-email" text={errors.email}/>)}
                                    <div
                                        className={(errors.password && touched.password) ? "error-login-password" : "input-wrapper"}>
                                        <Field
                                            name="password"
                                            className={(errors.password && touched.password) ? "input-data-error" : "input-data"}
                                            type={state ? "text" : "password"}
                                            placeholder="Password"
                                            label="Password"
                                            validationSchema={LogInSchema}
                                            value={values.password}
                                            onChange={handleChange}
                                            onBlur={handleBlur}
                                        />
                                        <img
                                            src={(errors.password && touched.password) ? passwordEyeError : passwordEye}
                                            onClick={() => handleClick(!state)}
                                            alt="password-eye"
                                            className="password-img"
                                        />
                                    </div>
                                    {errors.password && touched.password && (
                                        <FormErrorText class="error-text-password" text={errors.password}/>)}
                                    <div className="button-wrapper">
                                        <button
                                            className={(!isValid) ? "button-submit-error" : "button-submit"}
                                            type="submit"
                                        >LOG IN
                                        </button>
                                    </div>
                                    <div className="forgot-password-login">
                                        <a href="#">Forgot your password?</a>
                                    </div>
                                </Form>
                            )}
                        </Formik>
                        <FormFooter
                            divClass="login-footer"
                            spanClass="form-footer-login"
                            text="Don't have an account yet?"
                            link="#"
                            linkText="Register"
                        />
                    </Grid>
                </Paper>
            </Grid>
            <Grid item className={styles.footerImageWrapper}>
                <img src={FooterImage}/>
            </Grid>
        </Grid>
    );
}

export default LoginPage;
