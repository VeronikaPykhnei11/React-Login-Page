import React from 'react';
import "./FormFooter.css";

function FormFooter(props) {
    let link = props.link;
    return (
        <div className={props.divClass}>
            <span className={props.spanClass}>{props.text}</span>
            <a onClick={() => {}}>{props.linkText}</a>
        </div>
    )
}

export default FormFooter;