import React from 'react';
import footerLogo from "../../assets/images/footer-image-login.png";
import "./FooterImage.css";

function FooterImage() {
    return (
        <div className="footer-image-wrapper">
            <img src={footerLogo} className="footer-image"/>
        </div>
    );
}

export default FooterImage;
