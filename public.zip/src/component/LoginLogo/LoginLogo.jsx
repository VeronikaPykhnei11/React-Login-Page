import React from 'react';
import logo from "../../assets/images/login-logo.png";
import "./LoginLogo.css";

function LoginLogo() {
    return (
        <div className="login-logo-wrapper">
            <img src={logo} className="login-logo"/>
        </div>
    );
}

export default LoginLogo;
